// DEPRECATED
// Logic moved to Supabase Edge Function 'process-campaign'.
// This file is no longer used.
