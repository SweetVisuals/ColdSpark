import { exec } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import http from 'http';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const logPath = path.join(__dirname, 'install.log');

// Helper to log to file and console
function log(msg) {
    const entry = `[${new Date().toISOString()}] ${msg}\n`;
    fs.appendFileSync(logPath, entry);
    console.log(msg);
}

log("=== STARTING INSTALLER (installer.mjs) ===");

// 1. Check if package.json exists
const pkgPath = path.join(__dirname, 'package.json');
if (!fs.existsSync(pkgPath)) {
    log(`CRITICAL ERROR: package.json not found at ${pkgPath}. Cannot install dependencies.`);
} else {
    log(`Found package.json at ${pkgPath}. Proceeding with install...`);

    // 2. Run npm install
    // We use --omit=dev to speed it up and skip devDependencies (tsc, type defs)
    const command = 'npm install --omit=dev --no-audit --no-fund';
    log(`Executing command: ${command}`);

    const child = exec(command, { cwd: __dirname }, (error, stdout, stderr) => {
        if (error) {
            log(`INSTALLATION FAILED: ${error.message}`);
        } else {
            log('INSTALLATION SUCCESS!');
        }

        if (stdout) log(`STDOUT:\n${stdout}`);
        if (stderr) log(`STDERR:\n${stderr}`);

        log("=== INSTALLER FINISHED ===");
        log("You can now verify 'node_modules' exists, then switch startup file back to server/index.mjs");
    });
}

// 3. Start a dummy server so cPanel thinks the app is running
const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Installer is running in the background. Check install.log for progress.\n');
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
    log(`Installer Dummy Server listening on port ${PORT}`);
});
